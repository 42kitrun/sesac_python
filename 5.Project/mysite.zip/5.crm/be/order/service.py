# 필요시 model.py 에서 불러온 데이터를 비즈니스 로직 처리함
# model.py -> service.py -> routes.py